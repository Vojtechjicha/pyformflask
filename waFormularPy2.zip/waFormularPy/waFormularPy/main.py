import re
from flask import Flask
from flask import request, render_template
# from var_dump import var_dump
import json


f= open("students.csv","a")
ft= open("plany_trasy.txt","a")
app = Flask(__name__,static_url_path='/static', static_folder='static')

data = 0
@app.route('/')
def index():
    return render_template("index.html")

@app.route('/registrace.html')
def moje_zkouska():
    return render_template('registrace.html')

@app.route("/check.html", methods=["GET","POST"])
def check():
    jmeno = request.form['jmeno']
    prijmeni = request.form['prijmeni']
    je_plavec = (request.form["je_plavec"])
    kanoe_kamarad = request.form["kanoe_kamarad"]
    nick = request.form["nick"]
    ptrasy = request.form['trasa']
    if ((je_plavec == "T")):
        je_plavec = True
    else:
        je_plavec = False
    if je_plavec == False:
          return render_template("400.html")
        # return "<script> alert('musi obsahovat znaky anglické abecedy, číslice a velikost mezi 2 až 20 znaků')</script>"

    if not re.search("^[a-zA-Z0-9]{2,20}$", jmeno):
        return render_template("400.html")
    if not re.search("^[a-zA-Z0-9]{2,20}$", prijmeni):
        return render_template("400.html")
    if not re.search("^[a-zA-Z0-9]{2,20}$", nick):
        return render_template("400.html")
    if ((kanoe_kamarad == '') or not(re.search("^[a-zA-Z0-9]{2,20}$", kanoe_kamarad)) or nick==kanoe_kamarad):
        return render_template("400.html")

    f= open("students.csv","a")
    f.write(f'{nick},{jmeno},{prijmeni},{kanoe_kamarad} \n')
    ft= open("plany_trasy.txt","a")
    ft.write(f"{ptrasy} \n")
    return render_template("200.html")


# @app.route("/restapi/verze1/checkni_jmeno/<jm>")
# def zkontroluj_jmeno(jm):
#     soub = open('students.csv','r')
#     # for x in soub:
#     #     print(x)
#     #     print(jm)
#     #
#     #     if str(x)==str(jm): #request.form['nick']
#     #         return 'jmenu uz je v souboru'
#     # print(type(jm))
#     # return jm
#     while soub.readline():
#         print(soub.readline())
#         if soub.readline()==jm:
#             return 'je duplicitni'
#
#     return 'v poradku'

@app.route("/vypisStudentu.html")
def vypis_studentu():
    return render_template("vypisStudentu.html",soubor=open("students.csv","r"))

@app.route("/trasy.html")
def img_trasy():
    return render_template("trasy.html",fil=open("plany_trasy.txt","r"))

@app.route('/doc')
def dokumentace():
    return "program slouzi na zaregistrovani studentu do vodackeho<br>" \
           "kurzu. Program obsahuje formular kde dany student vyplni<br>" \
           "jmeno prijmeni nick zda umi plavat nebo ne a nepovine pole jmeno kamarada.<br>" \
           "Pokud uzivatel zada ze neumi plavat uzivatel neni zapsan do seznamu. Formular validuje jednotlive pole aby nesli zadat nesmysli. Po odeslani" \
           " je student zapsan do seznamu"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8888, debug=False)